Fosstrak Hardware Abstraction Layer Simulator Implementation
=========================================

The objective of the Fosstrak Hardware Abstraction Layer Simulator module is to provide
a HardwareAbstraction implementation without need for real hardware.


How to use the Hardware Abstraction Layer Simulator
=================================================

The module can be included in the Fosstrak Reader Project as a HardwareAbstraction implementation.

For more information,  please see http://www.fosstrak.org/hal